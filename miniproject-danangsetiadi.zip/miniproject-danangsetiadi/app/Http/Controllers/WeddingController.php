<?php

namespace App\Http\Controllers;

use App\Models\Wedding;

use Illuminate\View\View;

use Illuminate\Support\Facades\Storage;

use Illuminate\Http\Request;

class WeddingController extends Controller
{
    public function index(): View
    {
        $weddings = Wedding::orderBy('created_at', 'asc')->get();

        return view('wedding.index', compact('weddings'));
    }

    public function show(string $id): View
    {
        $wedding = Wedding::findOrFail($id);

        // $user = $wedding->user;

        return view('wedding.show', compact('wedding'));
    }

    public function create(): View
    {
        return view('wedding.create');
    }

    public function store(Request $request)
    {
        $this->validate($request, [
            'foto'     => 'required|image|mimes:jpeg,jpg,png,webp|max:2048'
        ]);

        $foto = $request->file('foto');
        $foto->storeAs('public/weddings', $foto->hashName());

        $user_id = auth()->id();

        Wedding::create([
            'user_id' => $user_id,
            'nama_pria' => $request->nama_pria,
            'nama_wanita' => $request->nama_wanita,
            'tgl_nikah' => $request->tgl_nikah,
            'maps' => $request->maps,
            'story' => $request->story,
            'foto' => $foto->hashName()
        ]);

        return redirect()->route('wedding.index');
    }

    public function destroy($id)
    {
        //get post by ID
        $wedding = Wedding::findOrFail($id);

        //delete image
        Storage::delete('public/weddings/'. $wedding->image);

        //delete post
        $wedding->delete();

        //redirect to index
        return redirect()->route('wedding.index');
    }
}
