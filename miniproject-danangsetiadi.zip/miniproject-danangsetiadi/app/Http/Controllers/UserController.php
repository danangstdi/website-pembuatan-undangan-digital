<?php

namespace App\Http\Controllers;

use App\Models\User;

use Illuminate\View\View;

use Illuminate\Support\Facades\Hash;

use Illuminate\Support\Facades\Auth;

use Illuminate\Http\Request;

class UserController extends Controller
{
    public function register()
    {
        if (Auth::check()) {
            return redirect()->route('home');
        }else{
            return view('auth.register');
        }
    }

    public function setRegister(Request $request)
    {
        $this->validate($request, [
            'password'   => 'min:6'
        ]);

        $user = User::create([
            'name'     => $request->name,
            'email'     => $request->email,
            'role' => 'user',
            'password'   => Hash::make($request->password)
        ]);

        //redirect to index
        return redirect('login');
    }

    public function login()
    {
        if (Auth::check()) {
            $user = Auth::user();
            if ($user->role === 'admin') {
                return redirect()->route('admin');
            } elseif ($user->role === 'user') {
                return redirect()->route('home');
            }
        }else{
            return view('auth.login');
        }
    }

    public function setLogin(Request $request)
{
    $data = [
        'email' => $request->input('email'),
        'password' => $request->input('password'),
    ];

    if (Auth::attempt($data)) {
        $user = Auth::user(); // Mendapatkan user yang sedang login

        if ($user->role === 'admin') {
            return redirect()->route('admin');
        } elseif ($user->role === 'user') {
            return redirect()->route('home');
        }
    } else {
        // return redirect()->route('login')->with('error', 'Email atau password salah.');
        return redirect()->route('login');
    }

    // Pengecekan gagal atau user tidak memiliki role yang sesuai
}

    public function logout()
    {
        Auth::logout();
        return redirect('login');
    }

}
