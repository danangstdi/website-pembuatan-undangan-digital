<?php

namespace App\Http\Controllers;

use Illuminate\View\View;

use Illuminate\Support\Facades\Auth;

use Illuminate\Http\Request;

class AdminController extends Controller
{
    public function admin()
    {
        if (Auth::check()) {
            $user = Auth::user();
            if ($user->role === 'admin') {
                return view('admin.index');
            } elseif ($user->role === 'user') {
                return redirect()->route('home');
            }
        }else{
            return view('auth.login');
        }
    }
}
