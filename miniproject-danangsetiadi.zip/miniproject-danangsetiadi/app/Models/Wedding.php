<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

use App\Models\User;

use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Wedding extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'nama_pria',
        'nama_wanita',
        'tgl_nikah',
        'maps',
        'story',
        'foto'
    ];

    public function user(): BelongsTo
    {
         return $this->belongsTo(User::class, 'user_id');
    }
}
