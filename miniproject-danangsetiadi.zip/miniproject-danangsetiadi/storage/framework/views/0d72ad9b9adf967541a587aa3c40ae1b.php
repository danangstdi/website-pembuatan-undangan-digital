<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Undanganku - <?php echo e($wedding->nama_pria); ?> & <?php echo e($wedding->nama_wanita); ?></title>
  <?php echo app('Illuminate\Foundation\Vite')('resources/css/main.css'); ?>
</head>
<body>
  <h1 class="text-3xl">Template 1</h1>

  <div>
    <label for="">Foto</label>
    <div class="h-40 w-40 overflow-hidden">
      <img src="<?php echo e(asset("storage/weddings/$wedding->foto")); ?>" alt="" class="object-cover">
    </div>
    
    <h1><?php echo e($wedding->nama_pria); ?> & <?php echo e($wedding->nama_wanita); ?></h1>

    <p><?php echo e($wedding->tgl_nikah); ?></p>

    <div>
      <label for="">Location:</label>
      <a href="<?php echo e($wedding->maps); ?>" class="text-blue-500">Maps</a>
    </div>
  </div>
</body>
</html><?php /**PATH C:\laragon\www\miniproject-danangsetiadi\resources\views/template/template-1.blade.php ENDPATH**/ ?>