<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Undanganku - Template</title>
  <?php echo app('Illuminate\Foundation\Vite')('resources/css/main.css'); ?>
</head>
<body class="bg-slate-200">
  <header class="bg-slate-50 py-5 shadow-lg grid md:grid-cols-3 grid-cols-2 px-10 items-center">
    <div>
      <a href="<?php echo e(route('home')); ?>" class="md:px-5 px-3 md:py-2 py-1 rounded-md bg-blue-400 hover:bg-blue-200 duration-200 text-white font-semibold">Kembali</a>
    </div>
    <h1 class="font-semibold mx-auto text-2xl">Undanganku</h1>
  </header>
  <div class="grid md:grid-cols-2 lg:grid-cols-3 mt-8 gap-6 md:px-6 lg:px-10">

    
    <?php $__empty_1 = true; $__currentLoopData = $templates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $template): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <div class="card mx-4 lg:mx-0 shadow-lg">
      <div class="p-4 mt-4 bg-slate-50 rounded-xl">
        <div class="flex flex-col mb-2">
          <h1 class="text-xl font-semibold"><?php echo e($template->template_name); ?> Template</h1>
          <a href="" class="text-xs text-slate-500">Dipakai sebanyak 1098 kali</a>
        </div>
        <div class="h-64 overflow-hidden rounded-xl">
          <img src="<?php echo e(asset('images/wedding.jpg')); ?>" alt="" class="w-full h-full object-cover">
        </div>
        <div class="flex flex-col text-center gap-2 mt-2 text-white font-semibold">
          <a href="<?php echo e(route('template.show', $template->id)); ?>" class="bg-yellow-400 hover:bg-yellow-200 rounded-md duration-200 py-2">Lihat Preview</a>
          <a href="<?php echo e(route('wedding.create', "template_id=$template->id")); ?>" class="bg-blue-400 hover:bg-blue-200 rounded-md duration-200 py-2">Pakai Template</a>
          <?php echo csrf_field(); ?>
        </div>
      </div>
    </div>
    
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <p>Belum ada template</p>
    <?php endif; ?>

    
  </div>

</body>
</html><?php /**PATH C:\laragon\www\miniproject-danangsetiadi\resources\views/template/index.blade.php ENDPATH**/ ?>