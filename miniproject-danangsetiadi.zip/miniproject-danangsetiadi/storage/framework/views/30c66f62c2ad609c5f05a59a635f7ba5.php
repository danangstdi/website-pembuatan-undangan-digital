<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Undanganku</title>
  <?php echo app('Illuminate\Foundation\Vite')('resources/css/main.css'); ?>
</head>
    <body class="bg-slate-100">
        
        <header>
            <nav class="flex items-center px-20 py-5 text-white relative">
                <h1 class="font-bold text-2xl">Undanganku</h1>
                <button onclick="navToggler()" class="ml-auto cursor-pointer md:hidden">
                    <span>-</span>
                </button>
                <ul id="nav" 
                class="md:flex md:gap-10 lg:gap-20 ml-auto lg:mx-auto md:font-semibold md:static hidden absolute right-10 left-10 top-16
                bg-slate-100 md:bg-transparent md:text-white text-black px-6 py-2 rounded-md">
                    <li class="hover:text-blue-300 duration-200">
                        <a href="">
                            Home
                        </a>
                    </li>
                    <li class="hover:text-blue-300 duration-200">
                        <a href="<?php echo e(route('wedding.index')); ?>">
                            Undangan Anda
                        </a>
                    </li>
                    <li class="hover:text-blue-300 duration-200">
                        <a href="">
                            Contact
                        </a>
                    </li>
                    <li class="hover:text-blue-300 duration-200">
                        <?php if(auth()->check()): ?>
                            <a href="<?php echo e(route('logout')); ?>">
                                Logout
                            </a>
                        <?php else: ?>
                            <a href="<?php echo e(route('login')); ?>">
                                Login
                            </a>
                        <?php endif; ?>
                    </li>
                </ul>
            </nav>

            <div class="flex flex-col items-center justify-center mt-48 text-white">
                <p class="md:text-5xl text-4xl">Buat Undangan Pernikahan</p>
                <p class="md:text-3xl text-2xl">Tanpa Ribet, Tanpa Biaya</p>
                <?php if(auth()->check()): ?>
                    <a href="<?php echo e(route('wedding.create')); ?>" 
                    class="bg-blue-400 px-6 py-2 rounded-full mt-4 md:mt-8 relative overflow-hidden z-10
                    before:bg-blue-200 before:absolute before:py-10 before:px-24 before:-top-5 before:-left-56 before:-z-10
                    hover:before:left-0 hover:before:duration-1000
                    hover:z-10 hover:text-slate-800 hover:duration-500">
                        Coba Sekarang
                    </a>
                <?php else: ?> 
                    <a href="<?php echo e(route('login')); ?>" 
                    class="bg-blue-400 px-6 py-2 rounded-full mt-4 md:mt-8 relative overflow-hidden z-10
                    before:bg-blue-200 before:absolute before:py-10 before:px-24 before:-top-5 before:-left-56 before:-z-10
                    hover:before:left-0 hover:before:duration-1000
                    hover:z-10 hover:text-slate-800 hover:duration-500">
                        Coba Sekarang
                    </a>
                <?php endif; ?>
            </div>

            <div class="w-full overflow-hidden backdrop-filter brightness-50 absolute top-0 -z-10 max-h-screen">
                <img src="<?php echo e(asset('images/wedding.jpg')); ?>" class="w-full h-full object-cover" alt="">
            </div>
        </header>


        <script>
            function navToggler() {
                const nav = document.getElementById('nav');

                if (nav.classList.contains('hidden')) {
                    nav.classList.remove('hidden');
                } else {
                    nav.classList.add('hidden')
                }
                }
        </script>
    </body>
</html>
<?php /**PATH C:\laragon\www\miniproject-danangsetiadi\resources\views/home/index.blade.php ENDPATH**/ ?>