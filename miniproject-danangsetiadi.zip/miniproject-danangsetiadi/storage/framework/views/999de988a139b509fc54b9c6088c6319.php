<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Undanganku - Masuk</title>
  <?php echo app('Illuminate\Foundation\Vite')('resources/css/main.css'); ?>
</head>
<body class="bg-slate-100 flex justify-center items-center min-h-screen">

  <div class="flex shadow-lg">
    <div class="bg-green-500 w-96 hidden md:block">
      
    </div>
    <div class="bg-white px-8 py-20 w-96 rounded-md">
      <div class="flex justify-center">
        <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" fill="currentColor" class="fill-green-500" viewBox="0 0 16 16">
          <path d="M8 8a3 3 0 1 0 0-6 3 3 0 0 0 0 6Zm2-3a2 2 0 1 1-4 0 2 2 0 0 1 4 0Zm4 8c0 1-1 1-1 1H3s-1 0-1-1 1-4 6-4 6 3 6 4Zm-1-.004c-.001-.246-.154-.986-.832-1.664C11.516 10.68 10.289 10 8 10c-2.29 0-3.516.68-4.168 1.332-.678.678-.83 1.418-.832 1.664h10Z"/>
        </svg>
      </div>
      <h1 class="text-center mb-8 text-2xl text-green-500 font-semibold">MASUK</h1>
      <form action="" method="post">
        <div class="flex flex-col gap-3">
          <input type="email" name="email" placeholder="Email" required class="bg-slate-200 px-4 py-2 rounded-md">
          <input type="password" name="password" placeholder="Password" required class="bg-slate-200 px-4 py-2 rounded-md">
          <a href="" class="text-green-500 hover:text-green-300 duration-100">Lupa Password?</a>
          <button type="submit" name="bgn-login" class="bg-green-500 hover:bg-green-300 duration-200 text-white py-2 rounded-md">Masuk</button>
          <p>Belum punya akun? <a href="<?php echo e(url('/register')); ?>" class="text-green-500 hover:text-green-300 duration-100">Daftar</a></p>
        </div>
      </form>
    </div>
  </div>

</body>
</html><?php /**PATH C:\laragon\www\miniproject-danangsetiadi\resources\views//auth/login.blade.php ENDPATH**/ ?>