<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Preview - <?php echo e($template->template_name); ?></title>
  <?php echo app('Illuminate\Foundation\Vite')('resources/css/main.css'); ?>
</head>
  <?php echo $template->code; ?>


</body>
</html><?php /**PATH C:\laragon\www\miniproject-danangsetiadi\resources\views/template/preview.blade.php ENDPATH**/ ?>