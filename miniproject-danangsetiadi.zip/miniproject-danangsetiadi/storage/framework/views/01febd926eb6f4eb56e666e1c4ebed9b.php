<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Document</title>
  <?php echo app('Illuminate\Foundation\Vite')('resources/css/main.css'); ?>
</head>
<body class="bg-slate-200">
  <div class="grid md:grid-cols-3">
    <div></div>

    <div>
      <header class="flex items-center bg-slate-50 mt-4 p-4 rounded-md shadow-lg">
        <a href="<?php echo e(route('home')); ?>" class="font-semibold">Kembali</a>
        <h1 class="ml-auto font-semibold text-xl">Undanganku</h1>
      </header>

      <main class="my-4">
        <div class="card bg-slate-50 px-4 py-4 shadow-lg rounded-lg">
          <h1 class="text-xl font-semibold pb-2">Buat Undangan Pernikahan </h1>

          <form action="<?php echo e(route('wedding.store')); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="flex flex-col gap-3">
              <div>
                <label for="">Pilih Foto Prewed</label>
                <input type="file" name="foto" class="bg-slate-200 px-4 py-2 rounded-md w-full">
              </div>
          
              <div>
                <input type="text" name="nama_pria" class="bg-slate-200 px-4 py-2 rounded-md w-full" autocomplete="off" placeholder="Nama Pengantin Pria">
              </div>
        
              <div>
                <input type="text" name="nama_wanita" autocomplete="off" placeholder="Nama Pengantin Wanita" class="bg-slate-200 px-4 py-2 rounded-md w-full">
              </div>
        
              <div>
                <input type="text" name="maps" autocomplete="off" placeholder="Lokasi Acara" class="bg-slate-200 px-4 py-2 rounded-md w-full">
              </div>

              <div>
                <textarea type="text" name="story" autocomplete="off" placeholder="How we meet?" class="bg-slate-200 px-4 py-2 rounded-md w-full"></textarea>
              </div>
        
              <div>
                <label for="">Tanggal Nikah</label>
                <input type="date" name="tgl_nikah" class="bg-slate-200 px-4 py-2 rounded-md w-full">
              </div>
        
              <button type="submit" class="bg-blue-400 hover:bg-blue-200 duration-200 text-white py-2 rounded-md">Buat</button>
            </div>
          </form>
          
        </div>
      </main>
    </div>

    <div></div>
  </div>
</body>
</html><?php /**PATH C:\laragon\www\miniproject-danangsetiadi\resources\views/wedding/create.blade.php ENDPATH**/ ?>