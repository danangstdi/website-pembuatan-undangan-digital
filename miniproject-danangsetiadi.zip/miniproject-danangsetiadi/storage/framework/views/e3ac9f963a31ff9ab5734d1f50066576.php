<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Wedding - <?php echo e($wedding->nama_pria); ?> & <?php echo e($wedding->nama_wanita); ?></title>
  <?php echo app('Illuminate\Foundation\Vite')('resources/css/main.css'); ?>
</head>

<body>
  <form action="" method="post">
    <input type="text" id="db_foto" value="<?php echo e($wedding->foto); ?>">
    <input type="text" id="db_nama_pria" value="<?php echo e($wedding->nama_pria); ?>">
    <input type="text" id="db_nama_wanita" value="<?php echo e($wedding->nama_wanita); ?>">
    <input type="text" id="db_tgl_nikah" value="<?php echo e($wedding->tgl_nikah); ?>">
    <input type="text" id="db_maps" value="<?php echo e($wedding->maps); ?>">
  </form>
  <h1 class="text-3xl">Template 1</h1>

  <div>
    <label for="">Foto</label>
    <div class="h-40 w-40 overflow-hidden">
      <img src="<?php echo e(asset("storage/weddings/$wedding->foto")); ?>" alt="" class="object-cover">
    </div>
    
    <h1><span id="nama_pria" onchange="view()"></span> & </h1>

    <p><?php echo e($wedding->tgl_nikah); ?></p>

    <div>
      <label for="">Location:</label>
      <a href="<?php echo e($wedding->maps); ?>" class="text-blue-500">Maps</a>
    </div>
  </div>
  

  <script>
    function view() {
      const foto = document.getElementById('db_nama_pria');
      const html = document.getElementById('nama_pria');

      html.innerHTML = foto.value;
    }
  </script>
</body>
</html><?php /**PATH C:\laragon\www\miniproject-danangsetiadi\resources\views/wedding/template_1.blade.php ENDPATH**/ ?>