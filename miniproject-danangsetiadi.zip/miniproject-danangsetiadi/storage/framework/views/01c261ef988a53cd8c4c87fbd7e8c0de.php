<?php
use Carbon\Carbon;
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Wedding - <?php echo e($wedding->nama_pria); ?> & <?php echo e($wedding->nama_wanita); ?></title>
  <?php echo app('Illuminate\Foundation\Vite')('resources/css/main.css'); ?>
</head>
<body class="bg-slate-200">
  <header>
    <div class="overflow-hidden" style="height: 30rem">
      <img src="<?php echo e(asset("storage/weddings/$wedding->foto")); ?>" alt="" class="w-full h-full object-cover">
    </div>
  </header>

  <main class="">
    <div class="bg-slate-50 m-5 md:m-10 rounded-ss-2xl rounded-ee-xl shadow-xl py-8">
      <div class="flex flex-col items-center justify-center mt-4">
        <h1 class="text-4xl"><?php echo e($wedding->nama_pria); ?></h1>
        <span class="text-xl">&</span>
        <h1 class="text-4xl"><?php echo e($wedding->nama_wanita); ?></h1>
      </div>
      <hr class="m-10 border-2">
      <div class="text-center font-semibold">
        <p>Tanggal:</p>
        <p><?php echo e($wedding->tgl_nikah); ?></p>
        <a href="<?php echo e($wedding->maps); ?>" class="font-normal text-blue-400 hover:text-blue-200 duration-200">
          Cek lokasi melalui Google Maps
        </a>
      </div>
      <hr class="m-10 border-2">
      <div class="text-center">
        <h1 class="font-semibold text-2xl">How we meet?</h1>
        <p class="text-left md:text-center px-10 lg:px-60 mt-4">
          <?php echo e($wedding->story); ?>

        </p>
      </div>
    </div>
  </main>
</body>
</html><?php /**PATH C:\laragon\www\miniproject-danangsetiadi\resources\views/wedding/show.blade.php ENDPATH**/ ?>