<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>List Undangan</title>
  @vite('resources/css/main.css')
</head>
<body class="bg-slate-200">
  <div class="grid md:grid-cols-3">
    <div></div>

    <div>
      <header class="flex items-center bg-slate-50 mt-4 p-4 rounded-md shadow-lg">
        <a href="{{ route('home') }}" class="font-semibold">Kembali</a>
        <h1 class="ml-auto font-semibold text-xl">Undanganku</h1>
      </header>

      @forelse ($weddings as $wedding)
      <main class="my-4">
        <div class="card bg-slate-50 px-4 py-4 shadow-lg rounded-lg">
          <h1 class="text-xl font-semibold pb-2">Pernikahan {{ $wedding->nama_pria }} & {{ $wedding->nama_wanita }}</h1>
          <div class="h-64 w-full overflow-hidden">
            <img src="{{ asset("storage/weddings/$wedding->foto") }}" alt="" class="object-cover h-full w-full">
          </div>
          <form action="{{ route('wedding.destroy', $wedding->id) }}" method="post">
            <div class="flex flex-col gap-2 justify-center w-full mt-2">
              <a href="{{ route('wedding.show', $wedding->id) }}" target="_blank" class="bg-blue-400 hover:bg-blue-200 duration-200 w-full text-center py-2 rounded-md text-white">
                Lihat
              </a>
              @csrf
              <button type="button" onclick="salinLink()" class="bg-yellow-400 hover:bg-yellow-200 duration-200 w-full text-center py-2 rounded-md text-white">
                Salin link
              </button>
              <input type="text" id="url" value="http://miniproject-danangsetiadi.test/wedding/{{ $wedding->id }}" readonly class="text-center text-xs bg-slate-200 rounded-sm py-1">
              @method('DELETE')
              <button type="submit" class="bg-red-400 hover:bg-red-200 duration-200 w-full text-center py-2 rounded-md text-white">
                Hapus
              </button>
            </div>
          </form>
        </div>
      </main>
      @empty
      <p class="text-center mt-10">Belum ada undangan yang dibuat</p>
      @endforelse
    </div>

    <div></div>
  </div>

  <script>
    function salinLink() {
      const url = document.getElementById('url');
      url.select();
      document.execCommand('copy');
    }
  </script>

</body>
</html>